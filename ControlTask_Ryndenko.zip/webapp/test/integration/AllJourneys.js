/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblessons/ControlTask_Ryndenko/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblessons/ControlTask_Ryndenko/test/integration/pages/Worklist",
	"zjblessons/ControlTask_Ryndenko/test/integration/pages/Object",
	"zjblessons/ControlTask_Ryndenko/test/integration/pages/NotFound",
	"zjblessons/ControlTask_Ryndenko/test/integration/pages/Browser",
	"zjblessons/ControlTask_Ryndenko/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblessons.ControlTask_Ryndenko.view."
	});

	sap.ui.require([
		"zjblessons/ControlTask_Ryndenko/test/integration/WorklistJourney",
		"zjblessons/ControlTask_Ryndenko/test/integration/ObjectJourney",
		"zjblessons/ControlTask_Ryndenko/test/integration/NavigationJourney",
		"zjblessons/ControlTask_Ryndenko/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});